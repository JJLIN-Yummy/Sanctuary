import Vue from "vue"
import App from "./App.vue"
import User from "./componets/User/User.vue"
import ElementUI from "element-ui"
Vue.use(ElementUI)
import 'element-ui/lib/theme-chalk/display.css';
import 'element-ui/lib/theme-chalk/index.css';
Vue.component(User.name,User)
//引入标准时间
import moment from 'moment'
moment.locale('zh-cn'); //设置语言 或 moment.lang('zh-cn'); 
Vue.prototype.$moment = moment;


import store from "./store/index.js"

Vue.config.productionTip = false

new Vue({
	el:'#app',
	render:h=>h(App),
	beforeCreate(){
		Vue.prototype.$bus = this
	},
	store
})

