<template>
	<el-container>
		<el-header class='title'>
			<el-row type='flex' justify='center' align='top'>
				<el-col class='a' :xs='24' :sm='10' :md='8' :lg='8'>用户信息管理页面</el-col>
			</el-row>
		</el-header>
		<el-main>
			<el-row type='flex' justify='space-between'>
				<el-col :xs='18' :sm='16' :md='12' :lg='8'>
					 <el-row class='search' type='flex' justify='start'>
						 <el-col :xs='12' :sm='10' :md='8' :lg='10' :xl='4'>查询用户信息：</el-col>
						 <el-col :xs='12' :sm='14' :md='12' :lg='14' :xl='10'>
							  <el-input
							    placeholder="请输入关键字..."
							    prefix-icon="el-icon-search"
							    v-model="input1"
								v-on:keyup.native='search'>
							  </el-input>
						 </el-col>
					 </el-row>
				</el-col>
				<el-col :xs='4' :sm='8' :md='4' :lg="2"><Add :userList = 'userList'></Add></el-col>
			</el-row>
			<el-row type='flex' justify='center'>
				<el-col :span='19.5'>
					<Table :userList = 'userList'></Table>
				</el-col>
			</el-row>
		</el-main>
	</el-container>
</template>

<script>
	import {mapState} from "vuex"
	// import 'element-ui/lib/theme-chalk/display.css';
	import Table from "./Table/Table.vue"
	import Add from "./Add/Add.vue"
	export default{
		name:'User',
		components:{
			Table,Add
		},
		data(){
			return{
				input1:''
			}
		},
		methods:{
			search(){
				this.$bus.$emit('search',this.input1)
			}
		},
		computed:{
			...mapState('user',['userList'])
		},
		beforeCreate(){
			this.$store.dispatch('user/getUser')
		}
	}
</script>

<style lang="less" scoped="scoped">
	@font-face{
		font-family: 'Dream';
		src: url('../../assets/fonts/genkai-mincho-2.ttf');
	}
	 .el-header, .el-footer {
	     background-color: #B3C0D1;
	     color: #333;
	     text-align: center;
	     line-height: 50px;
	   }
	   .el-main {
	     color: #333;
	     text-align: center;
	     line-height: 70px;
	   }
	  
	  
	  .el-row {
		height: 100%;
		margin-bottom: 0px;
	   }
	   .el-row:last-child {
	       margin-bottom: 0;
	     }
	   .el-col {
	     border-radius: 4px;
	   }
	   .bg-purple-dark {
	     background: #99a9bf;
	   }
	   .bg-purple {
	     background: #d3dce6;
	   }
	   .bg-purple-light {
	     background: #e5e9f2;
	   }
	   .grid-content {
	     border-radius: 4px;
	     min-height: 36px;
	   }
	   .row-bg {
	     padding: 10px 0;
	     background-color: #f9fafc;
	   }
	   // -----------------------------------------------------//
	   .title{
		   font-family: Dream;
		   font-size: 35px;
		   background-color: #ffffff;
		   .a{
			   
			   border-bottom: 2px solid deepskyblue;
		   }
	   }
	   .search{
		   font-size: 20px;
		   font-weight: 600;
	   }
</style>
