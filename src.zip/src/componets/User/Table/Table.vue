<template>
	<el-table :data="tableData" style="width: 100%" border align="center">
		<el-table-column prop="id" label="序号" width="120">
		</el-table-column>
		<el-table-column prop="date" label="日期" width="180">
		</el-table-column>
		<el-table-column prop="name" label="姓名" width='120'>
		</el-table-column>
		<el-table-column prop="email" label="邮箱" width='300'>
		</el-table-column>
		<el-table-column prop="title" label="标题" width='120'>
		</el-table-column>
		<el-table-column prop="address" label="地址" width='300'>
		</el-table-column>
		<el-table-column prop="state" label="状态" width='120'>
		</el-table-column>
		<el-table-column prop="operation" label="操作" width='240'>
			<el-row type='flex' justify='center' algin='middle' slot-scope="scope">
				 <el-col><Edit ref='id' @click.native.once.prevent='sendRow($event,scope.$index,tableData)' :data-id='`${tableData[scope.$index].id}`'></Edit></el-col>
				 <el-col><el-button type="danger"  @click.native.prevent="deleteRow(scope.$index, tableData)">删除</el-button></el-col>
			</el-row>
		</el-table-column>
	</el-table>
</template>

<script>
	import {mapState} from "vuex"
	import {delUserMsg} from "../../../api/index.js"
	import Edit from "../Edit/Edit.vue"
	export default {
		name: 'Table',
		props:['userList'],
		components:{
			Edit
		},
		data() {
			return {
				tableData: [],
				BeSearchedTableData:[]
			}
		},
		computed:{
			...mapState('user',['user_uid'])
		},
		methods:{
			//删除行
			 deleteRow(index, rows) {
			        let a = rows.splice(index, 1);
					//console.log(a)
					this.user_uid.splice(index,1)
					this.$store.commit('user/MODIFYUID',this.user_uid)
					console.log(a[0].id)
					 delUserMsg(a[0].id)
					 setTimeout(()=>{
						 this.$store.dispatch('user/getUser')
					 }, 500);
					 a = null
					
			},
			//修改行
			sendRow(e,index,rows){
				let a = rows[index]
				//let targetId = e.currentTarget.dataset.id
				this.$bus.$emit('getRow',a,this.user_uid[index])
				//a = null
				//targetId = null
				
			}
		},
		mounted(){
				const timer = setTimeout(()=>{
						this.tableData = this.userList
						this.BeSearchedTableData = this.userList
						clearTimeout(timer)
				}, 1000);
			this.$bus.$on('search',(value)=>{
				const newArry = this.BeSearchedTableData.filter((obj)=>{
					return obj.name.indexOf(value) != -1
				})
				this.tableData = newArry
			})
		},
		watch:{
			//监视原数组的变化
			userList:{
				immediate:true,
				deep:true,
				handler(newValue,OldValue){
					this.tableData = this.userList
					this.BeSearchedTableData= this.userList
				}
			}
		}
	}
</script>

<style>
</style>
