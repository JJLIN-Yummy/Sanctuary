<template>
	<div>
		<el-button type="primary" @click="dialogFormVisible = true" icon="el-icon-plus">添加</el-button>

		<el-dialog title="添加用户信息" :visible.sync="dialogFormVisible">
			<el-form :model="form" :rules="rules">
				<el-form-item label="日期" :label-width="formLabelWidth" prop="date">
					<el-date-picker type="date" placeholder="选择日期" v-model="form.date" style='width: 100%;'>
					</el-date-picker>
				</el-form-item>
				<el-form-item label="姓名" :label-width="formLabelWidth" prop="name">
					<el-input v-model="form.name" autocomplete="off"></el-input>
				</el-form-item>
				<el-form-item label="邮箱" :label-width="formLabelWidth" prop="email">
					<el-input v-model="form.email" autocomplete="off"></el-input>
				</el-form-item>
				<el-form-item label="标题" :label-width="formLabelWidth" prop="title">
					<el-input v-model="form.title" autocomplete="off"></el-input>
				</el-form-item>
				<el-form-item label="地址" :label-width="formLabelWidth" prop="address">
					<el-input v-model="form.address" autocomplete="off"></el-input>
				</el-form-item>
				<el-form-item label="状态" :label-width="formLabelWidth" prop="state">
					<el-input v-model="form.state" autocomplete="off"></el-input>
				</el-form-item>
			</el-form>
			<div slot="footer" class="dialog-footer">
				<el-button type="warning" @click="dialogFormVisible = false">取 消</el-button>
				<el-button type="danger" @click='clear'>清空</el-button>
				<el-button type="primary" @click="add">确 定</el-button>
			</div>
		</el-dialog>
	</div>
</template>

<script>
	import { postUserMsg } from "../../../api/index.js"
	export default {
		name: 'Add',
		props:['userList'],
		data() {
			return {
				dialogFormVisible: false,
				form: {
					date: '',
					name: '',
					email: '',
					title: '',
					address: '',
					state: '',
					// delivery: false,
					// type: [],
					// resource: '',
					// desc: ''
				},
				form2:{
					date: '',
					name: '',
					email: '',
					title: '',
					address: '',
					state: '',
					id:''
				},
				formLabelWidth: '120px',
				rules: {
					date: [{
						required: true,
						message: '请选择日期',
						trigger: 'change'
					}],
					name: [{
							required: true,
							message: '请输入您的名字',
							trigger: 'blur'
						},
						{
							min: 2,
							max: 6,
							message: '长度在 2 到 6 个字符',
							trigger: 'blur'
						}
					],
					email: [
						{ required: true, message: '请输入您的电子邮箱', trigger: 'blur' },
						{ type: 'email', message: '请输入正确的邮箱地址', trigger: 'blur' }
					],
					title:[
						{ required: true, message: '请输入您的标题', trigger: 'blur' },
					],
					address:[
						{ required: true, message: '请输入您的地址', trigger: 'blur' },
					],
					state:[
						{ required: true, message: '请输入该学生状态', trigger: 'blur' },
					]
				}
			}
		},
		methods:{
			 add(){
				this.dialogFormVisible = false
				if(this.form.name!=''){
					const newForm = this.form
					let date2 = this.form.date
					date2 = this.$moment(date2).format('YYYY-MM-DD');
					newForm.date=date2
					//newForm.id = `${this.userList.length+1}`
					postUserMsg(newForm)
					window.location.reload()
					this.$store.dispatch('user/getUser')
				}else{
					confirm('你还没有填写哟')
				}
			},
			clear(){
				if(confirm('你确定要清空吗？')){
				Object.assign(this.form,this.form2)
				}
			}
		}
	}
</script>

<style lang="less" scoped="scoped">
	.dialog-footer{
		display: flex;
		justify-content: space-around;
		align-items: center;
	}
</style>
