<template>
	<div id="app">
		
		<User></User>
	</div>
</template>

<script>
	export default{
		name:'App',
	}
</script>

<style lang="less" scoped="scoped">
	
</style>
