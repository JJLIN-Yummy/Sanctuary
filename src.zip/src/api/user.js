import axios from "axios"
import nprogress from 'nprogress'
import "nprogress/nprogress.css"

const userRequests = axios.create({
	baseURL:' http://localhost:3000',
	timeout:5000
})

userRequests.interceptors.request.use((config)=>{
	nprogress.start()
	return config
})

userRequests.interceptors.response.use((res)=>{
	nprogress.done()
	return res.data
},(err)=>{
	return Promise.reject(new Error('faile'))
})

export default userRequests