import userRequests from "./user.js"

export const reqUserList = ()=>{
	return userRequests({
		url:'/user',
		method:'GET'
	})
}

export const postUserMsg = (msg)=>{
	return userRequests({
		url:'/user',
		method:'POST',
		data:msg
	})
}

export const delUserMsg = (id)=>{
	return userRequests({
		url:`/user/${id}`,
		method:'delete'
	})
}

export const putUserMsg = (id,msg)=>{
	return userRequests({
		url:`/user/${id}`,
		method:'put',
		data:msg
	})
}
