import {reqUserList} from "../../api/index.js"
import { putUserMsg } from "../../api/index.js"

const user = {
	namespaced:true,
	actions:{
		async getUser({commit}){
			let result = await reqUserList()
			// for(let i = 0;i<result.length;i++){
			// 	result[i].id=`${i+1}`
			// }
				setTimeout(()=>{
					commit('GETUSER',result)
				}, 300);
		},
		async getModifyUser({commit},value){
			putUserMsg(value[0],value[1])
			let result = await reqUserList()
			setTimeout(()=>{
				commit('GETUSER',result)
			}, 300);
		}
	},
	mutations:{
		GETUSER(state,userList){
			setTimeout(()=>{
				state.userList = userList
			}, 100);
			//state.userList = userList
		},
		GETUID(state,uid){
			state.user_uid.push(uid)
		},
		MODIFYUID(state,newUid){
			state.user_uid = [...newUid]
		}
	},
	state:{
		userList:[],
		user_uid:[]
	},
	getters:{
		
	}
}

export default user