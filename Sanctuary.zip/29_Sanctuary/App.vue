<template>
	<div id="root">
		<MyHeader></MyHeader>
		<router-view v-if="$route.meta&&$route.name=='login'" :loginMessage='loginMessage'></router-view>
		<MyBody v-if="$route.meta && $route.name=='body'"></MyBody>
		<MyFooter v-if="!$route.meta"></MyFooter>
		
		<el-row :gutter="20">
		  <el-col :span="6"><div class="grid-content bg-purple"></div></el-col>
		  <el-col :span="6"><div class="grid-content bg-purple"></div></el-col>
		  <el-col :span="6"><div class="grid-content bg-purple"></div></el-col>
		  <el-col :span="6"><div class="grid-content bg-purple"></div></el-col>
		</el-row>
	</div>
</template>

<script>
	import MyHeader from './components/MyHeader.vue'
	import MyBody from './pages/BODY/MyBody.vue'
	import MyFooter from './components/MyFooter.vue'
	import axios from "axios"
	export default{
		name:'App',
		components:{MyHeader,MyBody,MyFooter},
		data(){
			return{
				loginMessage:[]
			}
		},
		mounted(){
			axios({
				method:'GET',
				url:'/mock/login',
			}).then(response=>{
				this.loginMessage = response.data.data.loginMessage
			})
		}
	}
</script>

<style lang="less">
	*{
		padding: 0;
		margin: 0;
	}
	#root{
		display: flex;
		flex-direction: column;
		height: 1024px;
		--color1:#01579b;
		--color2:#00838f;
		--color3:#ffd600;
		--color4:#ff4081;
		--color5:#f44336;
	}
	
	
	 .el-row {
	    margin-bottom: 20px;
	    &:last-child {
	      margin-bottom: 0;
	    }
	  }
	  .el-col {
	    border-radius: 4px;
	  }
	  .bg-purple-dark {
	    background: #99a9bf;
	  }
	  .bg-purple {
	    background: #d3dce6;
	  }
	  .bg-purple-light {
	    background: #e5e9f2;
	  }
	  .grid-content {
	    border-radius: 4px;
	    min-height: 36px;
	  }
	  .row-bg {
	    padding: 10px 0;
	    background-color: #f9fafc;
	  }
</style>
