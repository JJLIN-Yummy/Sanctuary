import VueRouter from "vue-router"
import MyBody from "../pages/BODY/MyBody.vue"
import Login from "../pages/Login.vue"
import Home from "../pages/Home/index.vue"
const router = new VueRouter({
	routes:[
		{
			name:'body',
			path:'/body',
			component:MyBody,
			meta:true,
		},
		{
			name:'login',
			path:'/login',
			component:Login,
			meta:true,
		},
		{
			name:'home',
			path:'/home',
			component:Home,
			meta:true,
		},
		{
			path:'*',
			redirect:'/body'
		}
	]
})

// router.beforeEach((to,from,next)=>{
	
// })

export default router