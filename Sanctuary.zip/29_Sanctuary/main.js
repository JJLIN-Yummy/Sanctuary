// 引入vue
import Vue from "vue"
// 引入App
import App from "./App.vue"

import VueRouter from "vue-router"
Vue.use(VueRouter)

import router from "./router/index.js"

import VueParticles from "vue-particles"
Vue.use(VueParticles)

import ElementUI from 'element-ui';
Vue.use(ElementUI);

//引入mock模拟数据
import './mock/mockServe.js'

Vue.config.productionTip=false


// 创建vm
new Vue({
	el:'#app',
	router,
	render:h=>h(App),
	beforeCreate(){
		Vue.prototype.$bus = this
	}
})