<template>
	<div class="navigation-bar">
		<ul>
			<li>
				<svg class="icon" aria-hidden="true">
				  <use xlink:href="#icon-shouye"></use>
				</svg>
				<a href="#">Home</a>
			</li>
			<li>
				<svg class="icon" aria-hidden="true">
				  <use xlink:href="#icon-renwushu"></use>
				</svg>
				<router-link :to="{path:'/login',isAuth:true}">Login</router-link>
			</li>
			<li>
				<svg class="icon" aria-hidden="true">
				  <use xlink:href="#icon-shipin"></use>
				</svg>
				<a href="#">Videos</a>
			</li>
			<li>
				<svg class="icon" aria-hidden="true">
				  <use xlink:href="#icon-tupian"></use>
				</svg>
				<a href="#">Photos</a>
			</li>
			<li>
				<svg class="icon" aria-hidden="true">
				  <use xlink:href="#icon-touxiang"></use>
				</svg>
				<a href="#">Mine</a>
			</li>
			<li>
				<svg class="icon" aria-hidden="true">
				  <use xlink:href="#icon-xiaoxi"></use>
				</svg>
				<a href="#">Messages</a>
			</li>
			<li>
				<svg class="icon" aria-hidden="true">
				  <use xlink:href="#icon-tongzhi"></use>
				</svg>
				<a href="#">Notification</a>
			</li>
			<li>
				<svg class="icon" aria-hidden="true">
				  <use xlink:href="#icon-peizhi"></use>
				</svg>
				<a href="#">Settings</a>
			</li>
		</ul>
	</div>
</template>


<script>
	export default{
		name:'NavigationBar',
		data(){
			return{
				Home:false
			}
		}
	}
</script>
<style scoped>
	@font-face {
		font-family: Dream;
		src: url('/前端/程序/vue项目/app/font/Dreaming-Regular.ttf');
	}
	
	/* 图标样式代码 */
	.icon {
	  width: 2.5em;
	  height: 1em;
	  vertical-align: -0.15em;
	fill: currentColor;
	  overflow: hidden;
	  border-radius: 30px 30px 0 0;
	  cursor: pointer;
	}
	/* 导航栏样式 */
	.navigation-bar{
		width: 100%;
		flex: 2;
		border-bottom: 1px solid;
		display: flex;
		}
	/* 小liflex布局 */
	ul{
		padding: 0;
		margin: 0;
		position: relative;
		display: flex;
		flex-wrap: wrap;
		align-items: center;
		width: 100%;
		list-style: none;
		opacity: 0.8;
	}
	li{	
		position: relative;
		width: 12%;
		height: 150px;
		margin-left: 190px;
		border-radius: 35px;
		display: flex;
		flex-direction: column;
		justify-content: center;
		align-items: center;
		box-shadow: 5px 5px 2px 2px grey;
		transition: .5s;
		}
	li svg{
		flex: 3;
		font-size: 90px;
		background-color: #fff;
		box-shadow: inset 5px 5px 8px 5px #ffcef3;
		}
	li svg:active{
		box-shadow: inset 5px 5px 8px 5px #edb1f1;
	}
	li a{
		width: 100%;
		flex: 1;
		border: 0.2px solid;
		border-radius: 0 0 35px 35px;
		display: flex;
		justify-content: center;
		align-items: center;
		text-decoration: none;
		font-family: Dream;
		font-size: 2.1875rem;
		font-weight: 600;
		transition: 1s;
	}
	a:link{
		color: rgb(85,26,139);
	}
	a:visited{
		color: rgb(85,26,139);
	}
	a:hover{
		color: rgb(85,26,139);
	}
	a:active{
		color: rgb(85,26,139);
	}
	
	
	li a:hover{
		background-color: mediumpurple;
		opacity: 0.8;
	}
	li:active{
		left: 1.5px;
		box-shadow: 3px 3px white ;
	}
	/* 文字 */
	ul::after{
		display: flex;
		justify-content: center;
		align-items: center;
		position: absolute;
		z-index: -1;
		width: 100%;
		height: 100%;
		content: 'MY SANCTUARY';
		font-size: 9.375rem;
		letter-spacing: 20px;
		font-weight: 500;
		background-color: #ebfffa;
		text-shadow: 5px 1px gray;
	}
</style>
