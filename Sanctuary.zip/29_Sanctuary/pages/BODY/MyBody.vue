<template>
	<div class="body">
		<NavigationBar></NavigationBar>
		<GoHome></GoHome>
	</div>
</template>

<script>
	import NavigationBar from './NavigationBar.vue'
	import GoHome from './GoHome.vue'
	
	export default{
		name:'MyBody',
		components:{NavigationBar,GoHome},
	}
</script>

<style scoped>
	.body{
		border-bottom: 1px solid;
		flex: 3;
		/* Body的flex布局样式 */
		display: flex;
		flex-direction: column;
	}
</style>
