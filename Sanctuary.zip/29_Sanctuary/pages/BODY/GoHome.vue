<template>
	<div class="go-home">
		<ul>
			<li><a href="#">乐行者</a></li>
			<li><a href="#">第二天堂</a></li>
			<li><a href="#">编号89757</a></li>
			<li><a href="#">曹操</a></li>
			<li><a href="#">西界</a></li>
			<li><a href="#">JJ陆</a></li>
			<li><a href="#">100天</a></li>
			<li><a href="#">她说</a></li>
			<li><a href="#">学不会</a></li>
			<li><a href="#">因你而在</a></li>
			<li><a href="#">新地球</a></li>
			<li><a href="#">和自己对话</a></li>
			<li><a href="#">伟大的渺小</a></li>
			<li><a href="#">幸存者·如你</a></li>
		</ul>
	</div>
</template>

<script>
	export default{
		name:'GoHome'
	}
</script>

<style scoped>
	.go-home{
		width: 100%;
		/* border: 1px solid; */
		flex: 1;
	}
	ul{
		position: relative;
		display: flex;
		list-style: none;
		justify-content: center;
		align-items: center;
		background-color: black;
	}
	ul li{
		position: relative;
		/* border: 1px solid; */
		height: 180px;
		flex: 1;
		display: flex;
		margin-left: 2px;
		transition: 1s;
		cursor: pointer;
		border-radius: 10px;
		opacity: 0.8;
	}
	ul li a{
		display: block;
		/* border: 1px solid; */
		position: relative;
		flex: 1;
		line-height: 30px;
		text-align: center;
		text-decoration: none;
		color: black;
		font-weight: 600;
		font-size: 18px;
		top: 177px;
		height: 20px;
		border: none;
	}
	ul li:nth-child(1){
		background: url(images/1.jpg);
		background-size: 130px 180px;
	}
	ul li:nth-child(2){
		background: url(images/2.jpg);
		background-size: 130px 180px;
	}
	ul li:nth-child(3){
		background: url(images/3.jpg);
		background-size: 130px 180px;
	}
	ul li:nth-child(4){
		background: url(images/4.jpg);
		background-size: 130px 180px;
	}
	ul li:nth-child(5){
		background: url(images/5.jpg);
		background-size: 130px 180px;
	}
	ul li:nth-child(6){
		background: url(images/6.jpg);
		background-size: 130px 180px;
	}
	ul li:nth-child(7){
		background: url(images/7.jpg);
		background-size: 130px 180px;
	}
	ul li:nth-child(8){
		background: url(images/8.jpg);
		background-size: 130px 180px;
	}
	ul li:nth-child(9){
		background: url(images/9.png);
		background-size: 130px 180px;
	}
	ul li:nth-child(10){
		background: url(images/10.jpg);
		background-size: 130px 180px;
	}
	ul li:nth-child(11){
		background: url(images/11.jpg);
		background-size: 130px 180px;
	}
	ul li:nth-child(12){
		background: url(images/12.jpg);
		background-size: 130px 180px;
	}
	ul li:nth-child(13){
		background: url(images/13.png);
		background-size: 130px 180px;
	}
	ul li:nth-child(14){
		background: url(images/14.png);
		background-size: 130px 180px;
	}
	ul li:hover{
		transform: scale(1.2);
	}
</style>
