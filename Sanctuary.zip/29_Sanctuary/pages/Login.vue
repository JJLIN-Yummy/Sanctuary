<template>
	<div class="login">
		<!-- <vue-particles
		color = '#521262'
		:particleOpacity='0.7'
		:particlesNumber='150'
		shapeType='circle'
		:particleSize='4'
		linesColor='#a56cc1'
		:linesWidth='1'
		:lineLinked='true'
		:lineOpacity='0.4'
		:linesDistance='150'
		:moveSpeed='2'
		:hoverEffect='true'
		hoverMode='grab'
		:clickEffect='false'
		clickMode='push'
		class='lizi'
		>
			
		</vue-particles> -->
		<h1>JUST LOG IN AND JOIN US</h1>
		<div class="login-box">
			<h2>Login</h2>
			<!-- <form  name="home"> -->
			<span>账号:<input type="text" name="account" id="account" placeholder="  请输入账号" v-model="account"/></span>
			<span>密码:<input type="password" name="password" id="password" placeholder="  请输入密码" v-model="password"></span>
			<span><button @click="toLogin">登录</button></span>
			<!-- </form> -->
		</div>
	</div>
</template>

<script>
	export default{
		name:'Login',
		data(){
			return{
				account:'',
				password:''
			}
		},
		props:['loginMessage'],
		methods:{
			toLogin(){
				if(this.account==this.loginMessage[0].account&&this.password==this.loginMessage[0].password){
					
					console.log('验证中')
					this.$router.push({
						name:'body'
					})
				}else{
					return false
				}
			}
		}
	}
</script>

<style scoped="scoped">
	
	.login{
		width: 100%;
		position: relative;
		flex: 4;
		display: flex;
		background-color: #1e2022;
	}
	h1{
		color: #fff;
		text-transform: uppercase;
		word-spacing: 100vw;
		width: min-content;
		text-align: center;
		font-family: "bodoni mt black";
		font-size: 15vh;
		line-height: 100%;
		background: linear-gradient(255deg,
		var(--color1)0%,var(--color1)9%,
		transparent 9%, transparent 10%,
		var(--color2)10%,var(--color2)19%,
		transparent 19%, transparent 20%,
		var(--color3)20%,var(--color3)29%,
		transparent 29%, transparent 30%,
		var(--color4)30%,var(--color4)39%,
		transparent 39%, transparent 40%,
		var(--color5)40%,var(--color5)49%,
		transparent 49%,transparent 50%,
		
		var(--color1)50%,var(--color1)59%,
		transparent 59%, transparent 60%,
		var(--color2)60%,var(--color2)69%,
		transparent 69%, transparent 70%,
		var(--color3)70%,var(--color3)79%,
		transparent 79%, transparent 80%,
		var(--color4)80%,var(--color4)89%,
		transparent 89%, transparent 90%,
		var(--color5)90%,var(--color5)99%,
		transparent 99%);
		
		background-size: 200% 200%;
		color: transparent;
		background-clip: text;
		-webkit-background-clip: text;
		animation: move 4s linear infinite;
	}
	@keyframes  move{
		0%{
			background-position: 0px 100%;
		}
		100%{
			background-position: 100% 0px;
		}
	}
	/*----------------------------------------------------*/
	.login-box{
		position: absolute;
		width: 50%;
		height: 70%;
		border: 1px solid;
		left: 30%;
		top: 100px;
		display: flex;
		justify-content: center;
		align-items: center;
		flex-direction: column;
		background: url('./login-images/1.jpg');
		background-position:50% center;
		background-repeat: no-repeat;
		border-radius: 20px;
		opacity: 0.8;
		box-shadow: 2px 2px 2px 2px mediumpurple;
	}
	h2{
		position: relative;
		top: -150px;
		font-size: 40px;
		font-weight: 600;
		letter-spacing: 5px;
		color: #a56cc1;
		
	}
	form{
		width: 100%;
		position: relative;
		display: flex;
		flex-direction: column;
		left: 30%;
	}
	input{
		width: 50%;
		margin: 10px; 
		border-radius: 10px;
		letter-spacing: 2px;
		outline: none;
		border: 1px solid;
		background-color: #dbedf3;
	}
	input::placeholder{
		color: #aa96da;
	}
	input:focus::placeholder{
		opacity: 0;
	}
	span{
		width: 70%;
		font-weight: 800;
		font-size: 20px;
		color: #7a08fa;
	}
	span button{
		position: absolute;
		margin: 10px;
		border-radius: 20px;
		width: 70px;
		height: 30px;
		left: 155px;
		font-size: 18px;
		color: #aa96da;
		background-color: #dbedf3;
	}
	/*-------------------粒子效果----------------------*/
	body{
		width: 100%;
		background-color: rgb(239,239,239);
	}
	.lizi{
		position: fixed;
		top: 0;
		width: 100%;
		height: 80%;
		z-index: 0;
		top: 30%;
	}
</style>
