<template>
	<div class="header" ref="header">
		<div class="main-title">
			<p class="name" @click="goHome">Sanctuary</p>
			<Song/>
		</div>
		<SecondTitle/>
	</div>
</template>

<script>
	import Song from './Song.vue'
	import SecondTitle from './SecondTitle.vue'
	export default {
		name: 'MyHeader',
		components:{Song,SecondTitle},
		methods:{
			goHome(){
				this.$router.push({
					name:'body'
				})
			}
		}
	}
</script>

<style scoped>
	@font-face {
		font-family: Ramona;
		src: url('/前端/程序/vue项目/app/font/Ramona-Bold.ttf');
	}

	@font-face {
		font-family: Dream;
		src: url('/前端/程序/vue项目/app/font/Dreaming-Regular.ttf');
	}
	@font-face {
		font-family:ZeroGothic;
		src: url('/前端/程序/vue项目/app/font/ZeroGothic.otf');
	}
	p{
		
	}
	.header {
		/* border: 1px solid; */
		width: 100%;
		flex: 1;
		display: flex;
		flex-direction: column;
	}

	.main-title {
		width: 100%;
		position: relative;
		box-sizing: border-box;
		display: flex;
		flex: 2;
		border: 10px solid;
		opacity: 0.8;
		letter-spacing: 10px;
		align-items: center;
		font-size: 5rem;
		font-weight: 600;
		background-color: #fff;
		font-family: ZeroGothic;
	}
	.name {
		position: absolute;
		left:35.5%;
		color: purple;
		flex: 2;
	}


</style>
