<template>
	<div class="footer">
		<List></List>
	</div>
</template>

<script>
	import List from './Lsit.vue'
	export default{
		name:'MyFooter',
		components:{List}
	}
</script>


<style type="text/css">
	.footer{
		/* border: 1px solid; */
		flex: 1;
		display: flex;
		background-color: #dff5f2;
		opacity: 1;
		color: black;
	}
</style>
