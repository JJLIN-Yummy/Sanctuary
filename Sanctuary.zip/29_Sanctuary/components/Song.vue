<template>
		<div class="SONG">

			<div 
			class="song" 
			ref="song" 
			:style="style" 
			v-show="show" 
			v-for="songObj in song" 
			:key="songObj.id">
				{{songObj.name}}
			</div>
		</div>
</template>

<script>
	export default {
		name: 'Song',
		data() {
			return {
				n: 0,
				song: [{
						id: '1',
						name: '乐行者'
					},
					{
						id: '2',
						name: '第二天堂'
					},
					{
						id: '3',
						name: '编号89757'
					},
					{
						id: '4',
						name: '西界'
					},
					{
						id: '5',
						name: 'JJ陆'
					},
					{
						id: '6',
						name: '100天'
					},
					{
						id: '7',
						name: '她说'
					},
					{
						id: '8',
						name: '学不会'
					},
					{
						id: '9',
						name: '因你而在'
					},
				],
				show: false,
				style: {
					opacity: '.3',
					transition: '3s',
					left: '',
					top: ''
				}
			}
		},
		methods: {
			start() {
				let timer = setInterval(() => {
					this.show = true
					for (let i = 0; i < this.song.length; i++) {
						let L = Math.random() * 1500
						let T = Math.random() * 20
						this.$refs.song[i].style.left = L + 'px'
						this.$refs.song[i].style.top = T + 'px'
					}
				}, 5000)
				clearInterval(timer)
			}
		},
		mounted() {
			this.start()
		}
	}
</script>

<style scoped>
	.SONG {
		height: 133px;
		display: flex;
		flex-direction: column;
		flex-wrap: wrap;
	}

	.song {
		position: relative;
		font-size: 15px;

	}
</style>
