<template>
	<div style="display: flex;">
	<div class="second-title">
		<p>S</p>
		<p>A</p>
		<p>N</p>
		<p>C</p>
		<p>T</p>
		<p>U</p>
		<p>A</p>
		<p>R</p>
		<p>Y</p>
	</div>
	</div>
</template>

<script>
	export default{
		name:'SecondTitle'
	}
</script>

<style scoped="">
	.second-title {
		display: flex;
		flex: 1;
		border: 1px solid;
		background-color: #6639a6;
		align-items: center;
		justify-content: center;
		font-size: 25px;
	}
	p{
		position: relative;
		left: -45px;
		width: 20px;
		height: 30px;
		line-height: 30px;
		margin-left: 100px;
		font-weight: 600;
		animation: 5s Rotate infinite;
		text-shadow: 2px 1px 1px black;
		
	}
	@keyframes Rotate{
		from{
			transform: rotateY(0);
		}
		to{
			transform: rotateY(360deg);
		}
	}
</style>
