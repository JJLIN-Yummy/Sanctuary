<template>
	<div class="list">
		<dl class="a">
			<dt>圣所指南</dt>
			<dd>专辑</dd>
			<dd>演唱会</dd>
			<dd>商品</dd>
		</dl>
		<dl class="b">
			<dt>服务中心</dt>
			<dd>申请售后</dd>
			<dd>订单查询</dd>
			<dd>保障服务</dd>
			<dd>防伪查询</dd>
		</dl>
		<dl class="c">
			<dt>线下门店</dt>
			<dd>圣所Sanctuary</dd>
		</dl>
	</div>
</template>

<script>
	export default{
		name:'List',
	}
</script>

<style scoped="scoped">
	.list{
		display: flex;
		/* border: 1px solid; */
		width: 100%;
		justify-content: center;
	}
	dl{
		width: 160px;
		margin-top: 10px;
		font-size: 20px;
		margin-left: 50px;
	}
	dd{
		position: relative;
		margin-top: 5px;
		font-size: 16px;
		font-weight: 600;
		cursor: pointer;
	}
	dd:active{
		color: #b292ea;
	}
</style>
