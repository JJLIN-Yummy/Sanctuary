import axios from "axios"
import nprogress from 'nprogress'
import "nprogress/nprogress.css"

const requests = axios()
//请求拦截器
requests.interceptors.request.use(function(config){
	nprogress.start()
	return config
})

//响应拦截器
requests.interceptors.response.use((response)=>{
	nprogress.done()
	return response.data
},(error)=>{
	console.log('出错啦')
})

export default requests