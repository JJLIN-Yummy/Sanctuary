import requests from "./request.js"

export const a = ()=>{
	return requests({
		
	})
}